'use client'

import { useEffect, useRef, useState } from 'react'
import { RotateCcw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

const SYMBOLS = ['★', '●', '▲', '■', '◆', '✚', '❤', '⬢']

type Card = { id: number; symbol: string; flipped: boolean; matched: boolean }

function shuffle(): Card[] {
  const deck = [...SYMBOLS, ...SYMBOLS]
    .map((symbol, i) => ({ symbol, sort: Math.random(), id: i }))
    .sort((a, b) => a.sort - b.sort)
    .map((c, i) => ({
      id: i,
      symbol: c.symbol,
      flipped: false,
      matched: false,
    }))
  return deck
}

export function MemoryMatch({ onScore }: { onScore?: (score: number) => void }) {
  const [cards, setCards] = useState<Card[]>(shuffle)
  const [picked, setPicked] = useState<number[]>([])
  const [moves, setMoves] = useState(0)
  const [locked, setLocked] = useState(false)
  const submitted = useRef(false)

  const won = cards.length > 0 && cards.every((c) => c.matched)

  useEffect(() => {
    if (won && !submitted.current) {
      submitted.current = true
      onScore?.(moves)
    }
  }, [won, moves, onScore])

  function flip(id: number) {
    if (locked) return
    const card = cards.find((c) => c.id === id)
    if (!card || card.flipped || card.matched) return

    const next = cards.map((c) => (c.id === id ? { ...c, flipped: true } : c))
    const nextPicked = [...picked, id]
    setCards(next)
    setPicked(nextPicked)

    if (nextPicked.length === 2) {
      setMoves((m) => m + 1)
      setLocked(true)
      const [a, b] = nextPicked
      const cardA = next.find((c) => c.id === a)!
      const cardB = next.find((c) => c.id === b)!

      if (cardA.symbol === cardB.symbol) {
        setTimeout(() => {
          setCards((cs) =>
            cs.map((c) =>
              c.id === a || c.id === b ? { ...c, matched: true } : c,
            ),
          )
          setPicked([])
          setLocked(false)
        }, 400)
      } else {
        setTimeout(() => {
          setCards((cs) =>
            cs.map((c) =>
              c.id === a || c.id === b ? { ...c, flipped: false } : c,
            ),
          )
          setPicked([])
          setLocked(false)
        }, 800)
      }
    }
  }

  function reset() {
    setCards(shuffle())
    setPicked([])
    setMoves(0)
    setLocked(false)
    submitted.current = false
  }

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="flex items-center gap-4">
        <div className="rounded-lg border border-border bg-card px-4 py-2 text-center">
          <p className="text-xs text-muted-foreground">Moves</p>
          <p className="font-mono text-2xl font-bold text-foreground">
            {moves}
          </p>
        </div>
        <div className="rounded-lg border border-border bg-card px-4 py-2 text-center">
          <p className="text-xs text-muted-foreground">Matched</p>
          <p className="font-mono text-2xl font-bold text-foreground">
            {cards.filter((c) => c.matched).length / 2}/{SYMBOLS.length}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-2 sm:gap-3">
        {cards.map((card) => {
          const face = card.flipped || card.matched
          return (
            <button
              key={card.id}
              onClick={() => flip(card.id)}
              disabled={face || locked}
              aria-label={face ? `Card ${card.symbol}` : 'Hidden card'}
              className={cn(
                'flex h-16 w-16 items-center justify-center rounded-xl border text-2xl font-bold transition-colors sm:h-20 sm:w-20',
                face
                  ? card.matched
                    ? 'border-primary/60 bg-primary/15 text-primary'
                    : 'border-border bg-secondary text-foreground'
                  : 'border-border bg-card text-transparent hover:bg-secondary',
              )}
            >
              {face ? card.symbol : '?'}
            </button>
          )
        })}
      </div>

      {won && (
        <p
          className="text-center text-sm font-medium text-primary"
          role="status"
          aria-live="polite"
        >
          Solved in {moves} moves!
        </p>
      )}

      <Button variant="secondary" onClick={reset}>
        <RotateCcw className="mr-2 h-4 w-4" />
        New game
      </Button>
    </div>
  )
}
