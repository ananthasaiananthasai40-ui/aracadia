import Link from 'next/link'
import { ArrowUpRight, Users } from 'lucide-react'
import type { GameMeta } from '@/lib/games'
import { Badge } from '@/components/ui/badge'
import { GameGlyph } from '@/components/game-glyph'

const CATEGORY_COLOR: Record<GameMeta['category'], string> = {
  Strategy: 'text-chart-2',
  Puzzle: 'text-chart-1',
  Arcade: 'text-chart-5',
  Memory: 'text-chart-4',
}

export function GameCard({ game }: { game: GameMeta }) {
  return (
    <Link
      href={`/games/${game.slug}`}
      className="group relative flex flex-col overflow-hidden rounded-2xl border border-border bg-card p-5 transition-colors hover:border-primary/60"
    >
      <div className="flex items-start justify-between">
        <div
          className={`flex h-14 w-14 items-center justify-center rounded-xl bg-secondary ${CATEGORY_COLOR[game.category]}`}
        >
          <GameGlyph slug={game.slug} className="h-7 w-7" />
        </div>
        <ArrowUpRight className="h-5 w-5 text-muted-foreground transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-primary" />
      </div>

      <h3 className="mt-4 text-lg font-bold text-foreground">{game.name}</h3>
      <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
        {game.description}
      </p>

      <div className="mt-4 flex items-center gap-2 pt-1">
        <Badge variant="secondary" className="font-normal">
          {game.category}
        </Badge>
        <span className="flex items-center gap-1 text-xs text-muted-foreground">
          <Users className="h-3.5 w-3.5" />
          {game.players}
        </span>
      </div>
    </Link>
  )
}
