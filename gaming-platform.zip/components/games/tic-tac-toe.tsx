'use client'

import { useState } from 'react'
import { RotateCcw, X, Circle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

type Cell = 'X' | 'O' | null
type Mode = 'cpu' | '2p'

const LINES = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6],
]

function winner(board: Cell[]): { player: Cell; line: number[] } | null {
  for (const line of LINES) {
    const [a, b, c] = line
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { player: board[a], line }
    }
  }
  return null
}

// Minimax for an unbeatable CPU playing 'O'.
function minimax(board: Cell[], isMax: boolean): number {
  const win = winner(board)
  if (win?.player === 'O') return 10
  if (win?.player === 'X') return -10
  if (board.every(Boolean)) return 0

  const scores: number[] = []
  board.forEach((cell, i) => {
    if (cell) return
    const next = [...board]
    next[i] = isMax ? 'O' : 'X'
    scores.push(minimax(next, !isMax))
  })
  return isMax ? Math.max(...scores) : Math.min(...scores)
}

function bestMove(board: Cell[]): number {
  let best = -Infinity
  let move = -1
  board.forEach((cell, i) => {
    if (cell) return
    const next = [...board]
    next[i] = 'O'
    const score = minimax(next, false)
    if (score > best) {
      best = score
      move = i
    }
  })
  return move
}

export function TicTacToe() {
  const [mode, setMode] = useState<Mode>('cpu')
  const [board, setBoard] = useState<Cell[]>(Array(9).fill(null))
  const [xTurn, setXTurn] = useState(true)
  const [busy, setBusy] = useState(false)

  const win = winner(board)
  const draw = !win && board.every(Boolean)
  const over = Boolean(win) || draw

  function play(i: number) {
    if (board[i] || over || busy) return
    const next = [...board]
    next[i] = xTurn ? 'X' : 'O'
    setBoard(next)

    if (mode === 'cpu' && xTurn && !winner(next) && !next.every(Boolean)) {
      setBusy(true)
      setTimeout(() => {
        const move = bestMove(next)
        if (move >= 0) next[move] = 'O'
        setBoard([...next])
        setBusy(false)
      }, 350)
    } else {
      setXTurn(!xTurn)
    }
  }

  function reset(nextMode: Mode = mode) {
    setMode(nextMode)
    setBoard(Array(9).fill(null))
    setXTurn(true)
    setBusy(false)
  }

  const status = win
    ? `${win.player} wins!`
    : draw
      ? "It's a draw"
      : mode === 'cpu'
        ? xTurn
          ? 'Your move (X)'
          : 'CPU thinking…'
        : `${xTurn ? 'X' : 'O'} to move`

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="flex gap-2 rounded-lg border border-border bg-card p-1">
        <button
          onClick={() => reset('cpu')}
          className={cn(
            'rounded-md px-3 py-1.5 text-sm font-medium transition-colors',
            mode === 'cpu'
              ? 'bg-primary text-primary-foreground'
              : 'text-muted-foreground hover:text-foreground',
          )}
        >
          vs CPU
        </button>
        <button
          onClick={() => reset('2p')}
          className={cn(
            'rounded-md px-3 py-1.5 text-sm font-medium transition-colors',
            mode === '2p'
              ? 'bg-primary text-primary-foreground'
              : 'text-muted-foreground hover:text-foreground',
          )}
        >
          2 players
        </button>
      </div>

      <p
        className="text-lg font-semibold text-foreground"
        role="status"
        aria-live="polite"
      >
        {status}
      </p>

      <div className="grid grid-cols-3 gap-2">
        {board.map((cell, i) => {
          const highlight = win?.line.includes(i)
          return (
            <button
              key={i}
              onClick={() => play(i)}
              disabled={Boolean(cell) || over || busy}
              aria-label={`Cell ${i + 1}${cell ? `, ${cell}` : ''}`}
              className={cn(
                'flex h-20 w-20 items-center justify-center rounded-xl border text-foreground transition-colors sm:h-24 sm:w-24',
                highlight
                  ? 'border-primary bg-primary/15'
                  : 'border-border bg-card hover:bg-secondary',
                !cell && !over && 'cursor-pointer',
              )}
            >
              {cell === 'X' && <X className="h-10 w-10 text-chart-2" />}
              {cell === 'O' && <Circle className="h-9 w-9 text-primary" />}
            </button>
          )
        })}
      </div>

      <Button variant="secondary" onClick={() => reset()}>
        <RotateCcw className="mr-2 h-4 w-4" />
        New game
      </Button>
    </div>
  )
}
