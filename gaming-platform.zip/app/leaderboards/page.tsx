import type { Metadata } from 'next'
import Link from 'next/link'
import { GAMES } from '@/lib/games'
import { getTopScores } from '@/app/actions/scores'
import { Leaderboard } from '@/components/leaderboard'
import { AdSlot } from '@/components/ad-slot'
import { GameGlyph } from '@/components/game-glyph'

export const metadata: Metadata = {
  title: 'Leaderboards — Arcadia',
  description: 'See the top scores across all Arcadia games and where you rank.',
}

export default async function LeaderboardsPage() {
  const ranked = GAMES.filter((g) => g.hasLeaderboard)
  const boards = await Promise.all(
    ranked.map(async (game) => ({
      game,
      rows: await getTopScores(game.slug, 5),
    })),
  )

  return (
    <main className="mx-auto max-w-7xl px-4 py-12">
      <header className="max-w-2xl">
        <h1 className="text-4xl font-bold tracking-tight text-foreground">
          Leaderboards
        </h1>
        <p className="mt-3 text-pretty leading-relaxed text-muted-foreground">
          The best of the best across Arcadia.{' '}
          <Link href="/sign-up" className="text-primary hover:underline">
            Sign up
          </Link>{' '}
          and start playing to claim your spot.
        </p>
      </header>

      <div className="mt-8">
        <AdSlot format="horizontal" slot="6666666666" className="h-24 md:h-28" />
      </div>

      <div className="mt-8 grid gap-6 md:grid-cols-2">
        {boards.map(({ game, rows }) => (
          <section
            key={game.slug}
            className="rounded-2xl border border-border bg-card/50 p-5"
          >
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary text-primary">
                  <GameGlyph slug={game.slug} className="h-5 w-5" />
                </span>
                <div>
                  <h2 className="font-bold text-foreground">{game.name}</h2>
                  <p className="text-xs text-muted-foreground">
                    Ranked by {game.scoreLabel.toLowerCase()}
                  </p>
                </div>
              </div>
              <Link
                href={`/games/${game.slug}`}
                className="text-sm font-medium text-primary hover:underline"
              >
                Play
              </Link>
            </div>
            <Leaderboard rows={rows} scoreLabel={game.scoreLabel} />
          </section>
        ))}
      </div>
    </main>
  )
}
