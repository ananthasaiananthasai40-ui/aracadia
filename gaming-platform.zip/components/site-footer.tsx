import Link from 'next/link'
import { Gamepad2 } from 'lucide-react'
import { GAMES } from '@/lib/games'

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-card/30">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 sm:grid-cols-2 md:grid-cols-4">
        <div className="sm:col-span-2 md:col-span-1">
          <Link href="/" className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Gamepad2 className="h-4 w-4" />
            </span>
            <span className="text-base font-bold text-foreground">Arcadia</span>
          </Link>
          <p className="mt-3 max-w-xs text-sm leading-relaxed text-muted-foreground">
            Free casual games you can play instantly in your browser. Sign up to
            save your high scores and climb the leaderboards.
          </p>
        </div>

        <div>
          <h3 className="text-sm font-semibold text-foreground">Games</h3>
          <ul className="mt-3 flex flex-col gap-2">
            {GAMES.slice(0, 4).map((g) => (
              <li key={g.slug}>
                <Link
                  href={`/games/${g.slug}`}
                  className="text-sm text-muted-foreground hover:text-foreground"
                >
                  {g.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-semibold text-foreground">Explore</h3>
          <ul className="mt-3 flex flex-col gap-2">
            <li>
              <Link
                href="/games"
                className="text-sm text-muted-foreground hover:text-foreground"
              >
                All games
              </Link>
            </li>
            <li>
              <Link
                href="/leaderboards"
                className="text-sm text-muted-foreground hover:text-foreground"
              >
                Leaderboards
              </Link>
            </li>
            <li>
              <Link
                href="/sign-up"
                className="text-sm text-muted-foreground hover:text-foreground"
              >
                Create account
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-semibold text-foreground">Account</h3>
          <ul className="mt-3 flex flex-col gap-2">
            <li>
              <Link
                href="/sign-in"
                className="text-sm text-muted-foreground hover:text-foreground"
              >
                Sign in
              </Link>
            </li>
            <li>
              <Link
                href="/sign-up"
                className="text-sm text-muted-foreground hover:text-foreground"
              >
                Sign up
              </Link>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-4 text-xs text-muted-foreground sm:flex-row">
          <p>© {new Date().getFullYear()} Arcadia. All rights reserved.</p>
          <p>Made for casual gamers everywhere.</p>
        </div>
      </div>
    </footer>
  )
}
