import Link from 'next/link'
import { Play, Trophy, Sparkles, Zap } from 'lucide-react'
import { GAMES } from '@/lib/games'
import { GameCard } from '@/components/game-card'
import { AdSlot } from '@/components/ad-slot'
import { Button } from '@/components/ui/button'

export default function HomePage() {
  const featured = GAMES.slice(0, 3)

  return (
    <main>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-primary/20 blur-3xl" />
        <div className="mx-auto max-w-7xl px-4 py-16 md:py-24">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
            <Sparkles className="h-3.5 w-3.5 text-primary" />
            Six free games, zero downloads
          </span>
          <h1 className="mt-6 max-w-3xl text-balance text-5xl font-bold leading-[1.05] tracking-tight text-foreground md:text-7xl">
            Play. Compete.{' '}
            <span className="text-primary">Beat your best.</span>
          </h1>
          <p className="mt-5 max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
            Arcadia is your home for quick, addictive browser games. Jump into a
            match in seconds, then sign up to save your scores and climb the
            leaderboards.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Button size="lg" nativeButton={false} render={<Link href="/games" />}>
              <Play className="mr-2 h-4 w-4" />
              Browse games
            </Button>
            <Button
              size="lg"
              variant="secondary"
              nativeButton={false}
              render={<Link href="/sign-up" />}
            >
              <Trophy className="mr-2 h-4 w-4" />
              Create free account
            </Button>
          </div>
        </div>
      </section>

      {/* Leaderboard banner ad */}
      <section className="mx-auto max-w-7xl px-4 pt-8">
        <AdSlot format="horizontal" slot="1111111111" className="h-24 md:h-28" />
      </section>

      {/* Featured games + sidebar ad */}
      <section className="mx-auto max-w-7xl px-4 py-12">
        <div className="grid gap-8 lg:grid-cols-[1fr_300px]">
          <div>
            <div className="flex items-end justify-between">
              <div>
                <h2 className="text-2xl font-bold tracking-tight text-foreground">
                  Featured games
                </h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Hand-picked favorites to get you started.
                </p>
              </div>
              <Link
                href="/games"
                className="text-sm font-medium text-primary hover:underline"
              >
                View all
              </Link>
            </div>
            <div className="mt-6 grid gap-5 sm:grid-cols-2">
              {featured.map((game) => (
                <GameCard key={game.slug} game={game} />
              ))}
            </div>
          </div>

          {/* Sidebar ad */}
          <aside className="hidden lg:block">
            <div className="sticky top-24">
              <AdSlot
                format="vertical"
                slot="2222222222"
                className="h-[600px]"
              />
            </div>
          </aside>
        </div>
      </section>

      {/* Why Arcadia */}
      <section className="border-y border-border bg-card/30">
        <div className="mx-auto grid max-w-7xl gap-6 px-4 py-12 md:grid-cols-3">
          {[
            {
              icon: Zap,
              title: 'Instant play',
              body: 'No installs, no waiting. Every game runs right in your browser on any device.',
            },
            {
              icon: Trophy,
              title: 'Saved high scores',
              body: 'Create an account to track your personal bests and appear on the leaderboards.',
            },
            {
              icon: Sparkles,
              title: 'Always free',
              body: 'Every game on Arcadia is free to play, supported by unobtrusive ads.',
            },
          ].map(({ icon: Icon, title, body }) => (
            <div
              key={title}
              className="rounded-2xl border border-border bg-card p-6"
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/15 text-primary">
                <Icon className="h-5 w-5" />
              </span>
              <h3 className="mt-4 text-lg font-semibold text-foreground">
                {title}
              </h3>
              <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                {body}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* All games grid */}
      <section className="mx-auto max-w-7xl px-4 py-12">
        <h2 className="text-2xl font-bold tracking-tight text-foreground">
          The full arcade
        </h2>
        <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {GAMES.map((game) => (
            <GameCard key={game.slug} game={game} />
          ))}
        </div>
      </section>

      {/* Bottom banner ad */}
      <section className="mx-auto max-w-7xl px-4 pb-12">
        <AdSlot format="horizontal" slot="3333333333" className="h-24 md:h-28" />
      </section>
    </main>
  )
}
