'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useState, useTransition } from 'react'
import { CheckCircle2, LogIn } from 'lucide-react'
import { submitScore } from '@/app/actions/scores'
import { useSession } from '@/lib/auth-client'
import type { GameMeta } from '@/lib/games'
import { TicTacToe } from '@/components/games/tic-tac-toe'
import { Game2048 } from '@/components/games/game-2048'
import { Snake } from '@/components/games/snake'
import { MemoryMatch } from '@/components/games/memory-match'
import { WhackAMole } from '@/components/games/whack-a-mole'
import { Sudoku } from '@/components/games/sudoku'

export function GameRunner({ game }: { game: GameMeta }) {
  const router = useRouter()
  const { data: session } = useSession()
  const [pending, startTransition] = useTransition()
  const [notice, setNotice] = useState<string | null>(null)

  function handleScore(score: number) {
    if (!session?.user) {
      setNotice('sign-in')
      return
    }
    startTransition(async () => {
      const res = await submitScore(game.slug, score)
      if (res.saved) {
        setNotice(`Saved your ${game.scoreLabel.toLowerCase()}: ${score}`)
        router.refresh()
      }
    })
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="rounded-2xl border border-border bg-card/50 p-6 md:p-8">
        {game.slug === 'tic-tac-toe' && <TicTacToe />}
        {game.slug === '2048' && <Game2048 onScore={handleScore} />}
        {game.slug === 'snake' && <Snake onScore={handleScore} />}
        {game.slug === 'memory-match' && <MemoryMatch onScore={handleScore} />}
        {game.slug === 'whack-a-mole' && <WhackAMole onScore={handleScore} />}
        {game.slug === 'sudoku' && <Sudoku onSolved={() => {}} />}
      </div>

      {game.hasLeaderboard && notice === 'sign-in' && (
        <div className="flex flex-wrap items-center gap-2 rounded-lg border border-primary/40 bg-primary/10 px-4 py-3 text-sm text-foreground">
          <LogIn className="h-4 w-4 text-primary" />
          <span>Sign in to save your score to the leaderboard.</span>
          <Link
            href="/sign-in"
            className="font-medium text-primary hover:underline"
          >
            Sign in
          </Link>
        </div>
      )}

      {game.hasLeaderboard && notice && notice !== 'sign-in' && (
        <div className="flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-3 text-sm text-foreground">
          <CheckCircle2 className="h-4 w-4 text-primary" />
          <span>{pending ? 'Saving…' : notice}</span>
        </div>
      )}
    </div>
  )
}
