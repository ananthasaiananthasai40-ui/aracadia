'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { Play, RotateCcw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

const GRID = 17
const SPEED = 120 // ms per step

type Point = { x: number; y: number }
type Dir = 'up' | 'down' | 'left' | 'right'

const START: Point[] = [
  { x: 8, y: 8 },
  { x: 7, y: 8 },
  { x: 6, y: 8 },
]

function randFood(snake: Point[]): Point {
  let p: Point
  do {
    p = { x: Math.floor(Math.random() * GRID), y: Math.floor(Math.random() * GRID) }
  } while (snake.some((s) => s.x === p.x && s.y === p.y))
  return p
}

export function Snake({ onScore }: { onScore?: (score: number) => void }) {
  const [snake, setSnake] = useState<Point[]>(START)
  const [food, setFood] = useState<Point>({ x: 12, y: 8 })
  const [dir, setDir] = useState<Dir>('right')
  const [running, setRunning] = useState(false)
  const [over, setOver] = useState(false)
  const [score, setScore] = useState(0)

  const dirRef = useRef<Dir>('right')
  const queued = useRef<Dir | null>(null)
  const submitted = useRef(false)

  const setDirection = useCallback((next: Dir) => {
    const opposite: Record<Dir, Dir> = {
      up: 'down',
      down: 'up',
      left: 'right',
      right: 'left',
    }
    if (next === opposite[dirRef.current]) return
    queued.current = next
  }, [])

  const step = useCallback(() => {
    setSnake((prev) => {
      const d = queued.current ?? dirRef.current
      dirRef.current = d
      queued.current = null

      const head = prev[0]
      const next: Point = {
        up: { x: head.x, y: head.y - 1 },
        down: { x: head.x, y: head.y + 1 },
        left: { x: head.x - 1, y: head.y },
        right: { x: head.x + 1, y: head.y },
      }[d]

      // Wall or self collision.
      const hitWall =
        next.x < 0 || next.y < 0 || next.x >= GRID || next.y >= GRID
      const hitSelf = prev.some((s) => s.x === next.x && s.y === next.y)
      if (hitWall || hitSelf) {
        setOver(true)
        setRunning(false)
        return prev
      }

      const grew = next.x === food.x && next.y === food.y
      const body = [next, ...prev]
      if (grew) {
        setScore((s) => s + 1)
        setFood(randFood(body))
      } else {
        body.pop()
      }
      return body
    })
  }, [food])

  useEffect(() => {
    if (!running) return
    const id = setInterval(step, SPEED)
    return () => clearInterval(id)
  }, [running, step])

  useEffect(() => {
    if (over && !submitted.current) {
      submitted.current = true
      if (score > 0) onScore?.(score)
    }
  }, [over, score, onScore])

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const map: Record<string, Dir> = {
        ArrowUp: 'up',
        ArrowDown: 'down',
        ArrowLeft: 'left',
        ArrowRight: 'right',
        w: 'up',
        s: 'down',
        a: 'left',
        d: 'right',
      }
      const next = map[e.key]
      if (next) {
        e.preventDefault()
        setDirection(next)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [setDirection])

  function start() {
    setSnake(START)
    setFood(randFood(START))
    setDir('right')
    dirRef.current = 'right'
    queued.current = null
    setScore(0)
    setOver(false)
    submitted.current = false
    setRunning(true)
  }

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="flex w-full max-w-md items-center justify-between">
        <div className="rounded-lg border border-border bg-card px-4 py-2">
          <p className="text-xs text-muted-foreground">Score</p>
          <p className="font-mono text-2xl font-bold text-foreground">
            {score}
          </p>
        </div>
        {running ? (
          <Button variant="secondary" onClick={() => setRunning(false)}>
            Pause
          </Button>
        ) : (
          <Button onClick={start}>
            {over ? (
              <RotateCcw className="mr-2 h-4 w-4" />
            ) : (
              <Play className="mr-2 h-4 w-4" />
            )}
            {over ? 'Play again' : score > 0 ? 'Restart' : 'Start'}
          </Button>
        )}
      </div>

      <div
        className="relative rounded-xl border border-border bg-card p-2"
        style={{ touchAction: 'none' }}
      >
        <div
          className="grid gap-px"
          style={{
            gridTemplateColumns: `repeat(${GRID}, minmax(0, 1fr))`,
            width: 'min(80vw, 360px)',
            height: 'min(80vw, 360px)',
          }}
        >
          {Array.from({ length: GRID * GRID }).map((_, i) => {
            const x = i % GRID
            const y = Math.floor(i / GRID)
            const isHead = snake[0].x === x && snake[0].y === y
            const isBody = !isHead && snake.some((s) => s.x === x && s.y === y)
            const isFood = food.x === x && food.y === y
            return (
              <div
                key={i}
                className={cn(
                  'rounded-[2px]',
                  isHead
                    ? 'bg-primary'
                    : isBody
                      ? 'bg-primary/60'
                      : isFood
                        ? 'bg-chart-3'
                        : 'bg-secondary/40',
                )}
              />
            )
          })}
        </div>

        {over && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 rounded-xl bg-background/85 backdrop-blur-sm">
            <p className="text-2xl font-bold text-foreground">Game over</p>
            <p className="text-sm text-muted-foreground">Score: {score}</p>
          </div>
        )}
      </div>

      {/* On-screen controls for touch devices */}
      <div className="grid grid-cols-3 gap-2 sm:hidden" aria-hidden={!running}>
        <span />
        <Button variant="secondary" size="icon" onClick={() => setDirection('up')}>
          ↑
        </Button>
        <span />
        <Button
          variant="secondary"
          size="icon"
          onClick={() => setDirection('left')}
        >
          ←
        </Button>
        <Button
          variant="secondary"
          size="icon"
          onClick={() => setDirection('down')}
        >
          ↓
        </Button>
        <Button
          variant="secondary"
          size="icon"
          onClick={() => setDirection('right')}
        >
          →
        </Button>
      </div>

      <p className="hidden text-center text-sm text-muted-foreground sm:block">
        Use arrow keys or WASD to steer.
      </p>
    </div>
  )
}
