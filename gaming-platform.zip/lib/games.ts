export type GameMeta = {
  slug: string
  name: string
  tagline: string
  description: string
  category: 'Strategy' | 'Puzzle' | 'Arcade' | 'Memory'
  players: string
  // Whether this game reports a numeric score to the leaderboard.
  hasLeaderboard: boolean
  // Higher score is better (true) vs. lower is better e.g. time/moves (false).
  higherIsBetter: boolean
  scoreLabel: string
}

export const GAMES: GameMeta[] = [
  {
    slug: 'tic-tac-toe',
    name: 'Tic-Tac-Toe',
    tagline: 'Outsmart the machine',
    description:
      'The timeless 3x3 duel. Play against a friend or challenge our unbeatable CPU.',
    category: 'Strategy',
    players: '1-2 players',
    hasLeaderboard: false,
    higherIsBetter: true,
    scoreLabel: 'Wins',
  },
  {
    slug: '2048',
    name: '2048',
    tagline: 'Slide, merge, conquer',
    description:
      'Combine matching tiles to reach 2048 — and then keep going for the ultimate high score.',
    category: 'Puzzle',
    players: '1 player',
    hasLeaderboard: true,
    higherIsBetter: true,
    scoreLabel: 'Score',
  },
  {
    slug: 'snake',
    name: 'Snake',
    tagline: 'Grow without crashing',
    description:
      'Guide the snake, gobble the pellets, and grow as long as you can without biting yourself.',
    category: 'Arcade',
    players: '1 player',
    hasLeaderboard: true,
    higherIsBetter: true,
    scoreLabel: 'Score',
  },
  {
    slug: 'memory-match',
    name: 'Memory Match',
    tagline: 'Test your recall',
    description:
      'Flip cards to find every matching pair. Fewer moves means a better score.',
    category: 'Memory',
    players: '1 player',
    hasLeaderboard: true,
    higherIsBetter: false,
    scoreLabel: 'Moves',
  },
  {
    slug: 'whack-a-mole',
    name: 'Whack-a-Mole',
    tagline: 'Reflexes on fire',
    description:
      'Bop as many moles as you can before the 30-second timer runs out.',
    category: 'Arcade',
    players: '1 player',
    hasLeaderboard: true,
    higherIsBetter: true,
    scoreLabel: 'Hits',
  },
  {
    slug: 'sudoku',
    name: 'Sudoku',
    tagline: 'Logic, one cell at a time',
    description:
      'Fill the 9x9 grid so every row, column, and box contains 1 through 9.',
    category: 'Puzzle',
    players: '1 player',
    hasLeaderboard: false,
    higherIsBetter: true,
    scoreLabel: 'Solved',
  },
]

export function getGame(slug: string): GameMeta | undefined {
  return GAMES.find((g) => g.slug === slug)
}
