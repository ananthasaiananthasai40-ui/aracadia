'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { RotateCcw, Timer } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { GameGlyph } from '@/components/game-glyph'
import { cn } from '@/lib/utils'

const HOLES = 9
const ROUND = 30 // seconds

export function WhackAMole({ onScore }: { onScore?: (score: number) => void }) {
  const [active, setActive] = useState<number | null>(null)
  const [score, setScore] = useState(0)
  const [time, setTime] = useState(ROUND)
  const [running, setRunning] = useState(false)
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const moleRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const stop = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current)
    if (moleRef.current) clearInterval(moleRef.current)
    timerRef.current = null
    moleRef.current = null
    setRunning(false)
    setActive(null)
  }, [])

  const start = useCallback(() => {
    setScore(0)
    setTime(ROUND)
    setRunning(true)
    setActive(Math.floor(Math.random() * HOLES))

    moleRef.current = setInterval(() => {
      setActive(Math.floor(Math.random() * HOLES))
    }, 750)

    timerRef.current = setInterval(() => {
      setTime((t) => {
        if (t <= 1) {
          if (timerRef.current) clearInterval(timerRef.current)
          if (moleRef.current) clearInterval(moleRef.current)
          timerRef.current = null
          moleRef.current = null
          setRunning(false)
          setActive(null)
          return 0
        }
        return t - 1
      })
    }, 1000)
  }, [])

  useEffect(() => stop, [stop])

  // Submit score when the round ends with hits recorded.
  const endedRef = useRef(false)
  useEffect(() => {
    if (time === 0 && !running) {
      if (!endedRef.current) {
        endedRef.current = true
        if (score > 0) onScore?.(score)
      }
    } else {
      endedRef.current = false
    }
  }, [time, running, score, onScore])

  function whack(i: number) {
    if (!running || i !== active) return
    setScore((s) => s + 1)
    setActive(null)
  }

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="flex w-full max-w-sm items-center justify-between">
        <div className="rounded-lg border border-border bg-card px-4 py-2">
          <p className="text-xs text-muted-foreground">Hits</p>
          <p className="font-mono text-2xl font-bold text-foreground">
            {score}
          </p>
        </div>
        <div className="flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-2">
          <Timer className="h-4 w-4 text-primary" />
          <span className="font-mono text-2xl font-bold text-foreground">
            {time}s
          </span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {Array.from({ length: HOLES }).map((_, i) => {
          const up = running && i === active
          return (
            <button
              key={i}
              onClick={() => whack(i)}
              disabled={!running}
              aria-label={up ? 'Mole up — whack it!' : 'Empty hole'}
              className={cn(
                'flex h-24 w-24 items-center justify-center overflow-hidden rounded-full border-2 transition-colors',
                up
                  ? 'border-primary bg-primary/20'
                  : 'border-border bg-secondary',
              )}
            >
              <GameGlyph
                slug="whack-a-mole"
                className={cn(
                  'h-10 w-10 transition-all duration-150',
                  up
                    ? 'scale-100 text-primary opacity-100'
                    : 'scale-50 opacity-0',
                )}
              />
            </button>
          )
        })}
      </div>

      {running ? (
        <Button variant="secondary" onClick={stop}>
          Stop
        </Button>
      ) : (
        <Button onClick={start}>
          <RotateCcw className="mr-2 h-4 w-4" />
          {time === 0 ? 'Play again' : 'Start game'}
        </Button>
      )}

      {time === 0 && !running && (
        <p
          className="text-center text-sm text-muted-foreground"
          role="status"
          aria-live="polite"
        >
          Time! You whacked {score} {score === 1 ? 'mole' : 'moles'}.
        </p>
      )}
    </div>
  )
}
