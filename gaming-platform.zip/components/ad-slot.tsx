'use client'

import { useEffect, useRef } from 'react'
import { cn } from '@/lib/utils'

type AdFormat = 'auto' | 'horizontal' | 'rectangle' | 'vertical'

type AdSlotProps = {
  /** The AdSense ad unit slot ID, e.g. "1234567890". */
  slot?: string
  format?: AdFormat
  /** Tailwind classes controlling the reserved space for the ad. */
  className?: string
  label?: string
}

const ADSENSE_CLIENT = process.env.NEXT_PUBLIC_ADSENSE_CLIENT

declare global {
  interface Window {
    adsbygoogle?: unknown[]
  }
}

/**
 * A Google AdSense–ready ad slot.
 *
 * When NEXT_PUBLIC_ADSENSE_CLIENT is set, this renders a real <ins.adsbygoogle>
 * unit and pushes it to AdSense. Until then (and in the v0 preview) it renders a
 * clearly-labelled placeholder so the layout is designed around the real ad size.
 *
 * To go live:
 *  1. Add NEXT_PUBLIC_ADSENSE_CLIENT (your "ca-pub-..." id) to your env vars.
 *  2. Pass the ad unit `slot` id for each placement.
 */
export function AdSlot({
  slot,
  format = 'auto',
  className,
  label = 'Advertisement',
}: AdSlotProps) {
  const pushed = useRef(false)

  useEffect(() => {
    if (!ADSENSE_CLIENT || !slot || pushed.current) return
    try {
      ;(window.adsbygoogle = window.adsbygoogle || []).push({})
      pushed.current = true
    } catch {
      // AdSense not ready yet — it will retry on next mount.
    }
  }, [slot])

  const isLive = Boolean(ADSENSE_CLIENT && slot)

  return (
    <div
      className={cn(
        'relative w-full overflow-hidden rounded-xl border border-dashed border-border bg-card/40',
        className,
      )}
      aria-label={label}
      role="complementary"
    >
      <span className="pointer-events-none absolute left-2 top-2 z-10 rounded bg-background/70 px-1.5 py-0.5 text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
        {label}
      </span>

      {isLive ? (
        <ins
          className="adsbygoogle"
          style={{ display: 'block', width: '100%', height: '100%' }}
          data-ad-client={ADSENSE_CLIENT}
          data-ad-slot={slot}
          data-ad-format={format}
          data-full-width-responsive="true"
        />
      ) : (
        <div className="flex h-full min-h-24 w-full items-center justify-center p-4 text-center">
          <div className="flex flex-col items-center gap-1">
            <span className="text-sm font-medium text-muted-foreground">
              Ad space available
            </span>
            <span className="text-xs text-muted-foreground/70">
              {format === 'vertical'
                ? '300 x 600'
                : format === 'rectangle'
                  ? '300 x 250'
                  : '728 x 90'}
            </span>
          </div>
        </div>
      )}
    </div>
  )
}
