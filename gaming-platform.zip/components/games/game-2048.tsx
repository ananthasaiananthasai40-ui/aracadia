'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { RotateCcw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

const SIZE = 4
type Grid = number[][]

function empty(): Grid {
  return Array.from({ length: SIZE }, () => Array(SIZE).fill(0))
}

function addRandom(grid: Grid): Grid {
  const cells: [number, number][] = []
  grid.forEach((row, r) =>
    row.forEach((v, c) => {
      if (v === 0) cells.push([r, c])
    }),
  )
  if (cells.length === 0) return grid
  const [r, c] = cells[Math.floor(Math.random() * cells.length)]
  const next = grid.map((row) => [...row])
  next[r][c] = Math.random() < 0.9 ? 2 : 4
  return next
}

function init(): Grid {
  return addRandom(addRandom(empty()))
}

function slide(row: number[]): { row: number[]; gained: number } {
  const filtered = row.filter((v) => v !== 0)
  const result: number[] = []
  let gained = 0
  for (let i = 0; i < filtered.length; i++) {
    if (filtered[i] === filtered[i + 1]) {
      const merged = filtered[i] * 2
      result.push(merged)
      gained += merged
      i++
    } else {
      result.push(filtered[i])
    }
  }
  while (result.length < SIZE) result.push(0)
  return { row: result, gained }
}

function transpose(g: Grid): Grid {
  return g[0].map((_, c) => g.map((row) => row[c]))
}

function reverse(g: Grid): Grid {
  return g.map((row) => [...row].reverse())
}

type Dir = 'left' | 'right' | 'up' | 'down'

function move(grid: Grid, dir: Dir): { grid: Grid; gained: number; moved: boolean } {
  let work = grid
  if (dir === 'up' || dir === 'down') work = transpose(work)
  if (dir === 'right' || dir === 'down') work = reverse(work)

  let gained = 0
  const slid = work.map((row) => {
    const s = slide(row)
    gained += s.gained
    return s.row
  })

  let result = slid
  if (dir === 'right' || dir === 'down') result = reverse(result)
  if (dir === 'up' || dir === 'down') result = transpose(result)

  const moved = JSON.stringify(result) !== JSON.stringify(grid)
  return { grid: result, gained, moved }
}

function canMove(grid: Grid): boolean {
  for (const dir of ['left', 'right', 'up', 'down'] as Dir[]) {
    if (move(grid, dir).moved) return true
  }
  return false
}

const TILE_STYLE: Record<number, string> = {
  0: 'bg-secondary/40 text-transparent',
  2: 'bg-secondary text-foreground',
  4: 'bg-muted text-foreground',
  8: 'bg-chart-3/30 text-foreground',
  16: 'bg-chart-3/50 text-foreground',
  32: 'bg-chart-5/40 text-foreground',
  64: 'bg-chart-5/60 text-foreground',
  128: 'bg-primary/40 text-foreground',
  256: 'bg-primary/60 text-foreground',
  512: 'bg-primary/80 text-primary-foreground',
  1024: 'bg-primary text-primary-foreground',
  2048: 'bg-primary text-primary-foreground ring-2 ring-primary',
}

export function Game2048({ onScore }: { onScore?: (score: number) => void }) {
  const [grid, setGrid] = useState<Grid>(init)
  const [score, setScore] = useState(0)
  const [over, setOver] = useState(false)
  const submitted = useRef(false)

  const doMove = useCallback(
    (dir: Dir) => {
      setGrid((current) => {
        if (over) return current
        const { grid: next, gained, moved } = move(current, dir)
        if (!moved) return current
        const withNew = addRandom(next)
        setScore((s) => s + gained)
        if (!canMove(withNew)) setOver(true)
        return withNew
      })
    },
    [over],
  )

  useEffect(() => {
    if (over && !submitted.current) {
      submitted.current = true
      if (score > 0) onScore?.(score)
    }
  }, [over, score, onScore])

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const map: Record<string, Dir> = {
        ArrowLeft: 'left',
        ArrowRight: 'right',
        ArrowUp: 'up',
        ArrowDown: 'down',
      }
      const dir = map[e.key]
      if (dir) {
        e.preventDefault()
        doMove(dir)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [doMove])

  // Touch / swipe support.
  const touch = useRef<{ x: number; y: number } | null>(null)
  function onTouchStart(e: React.TouchEvent) {
    touch.current = { x: e.touches[0].clientX, y: e.touches[0].clientY }
  }
  function onTouchEnd(e: React.TouchEvent) {
    if (!touch.current) return
    const dx = e.changedTouches[0].clientX - touch.current.x
    const dy = e.changedTouches[0].clientY - touch.current.y
    if (Math.max(Math.abs(dx), Math.abs(dy)) < 24) return
    if (Math.abs(dx) > Math.abs(dy)) doMove(dx > 0 ? 'right' : 'left')
    else doMove(dy > 0 ? 'down' : 'up')
    touch.current = null
  }

  function reset() {
    setGrid(init())
    setScore(0)
    setOver(false)
    submitted.current = false
  }

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="flex w-full max-w-xs items-center justify-between">
        <div className="rounded-lg border border-border bg-card px-4 py-2">
          <p className="text-xs text-muted-foreground">Score</p>
          <p className="font-mono text-2xl font-bold text-foreground">
            {score}
          </p>
        </div>
        <Button variant="secondary" onClick={reset}>
          <RotateCcw className="mr-2 h-4 w-4" />
          New game
        </Button>
      </div>

      <div
        className="relative touch-none rounded-xl border border-border bg-card p-2"
        onTouchStart={onTouchStart}
        onTouchEnd={onTouchEnd}
      >
        <div className="grid grid-cols-4 gap-2">
          {grid.flat().map((v, i) => (
            <div
              key={i}
              className={cn(
                'flex h-16 w-16 items-center justify-center rounded-lg text-xl font-bold tabular-nums sm:h-20 sm:w-20 sm:text-2xl',
                TILE_STYLE[v] ?? 'bg-primary text-primary-foreground',
              )}
            >
              {v || ''}
            </div>
          ))}
        </div>

        {over && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 rounded-xl bg-background/85 backdrop-blur-sm">
            <p className="text-2xl font-bold text-foreground">Game over</p>
            <p className="text-sm text-muted-foreground">Final score: {score}</p>
            <Button onClick={reset}>Try again</Button>
          </div>
        )}
      </div>

      <p className="text-center text-sm text-muted-foreground">
        Use arrow keys or swipe to move the tiles.
      </p>
    </div>
  )
}
