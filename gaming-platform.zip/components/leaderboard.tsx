import { Crown, Medal } from 'lucide-react'
import type { ScoreRow } from '@/app/actions/scores'
import { cn } from '@/lib/utils'

export function Leaderboard({
  rows,
  scoreLabel,
  emptyHint = 'No scores yet. Be the first!',
}: {
  rows: ScoreRow[]
  scoreLabel: string
  emptyHint?: string
}) {
  if (rows.length === 0) {
    return (
      <p className="rounded-lg border border-dashed border-border px-4 py-6 text-center text-sm text-muted-foreground">
        {emptyHint}
      </p>
    )
  }

  return (
    <ol className="flex flex-col gap-1.5">
      {rows.map((row, i) => (
        <li
          key={row.id}
          className={cn(
            'flex items-center gap-3 rounded-lg border px-3 py-2 text-sm',
            row.isMe
              ? 'border-primary/50 bg-primary/10'
              : 'border-border bg-card',
          )}
        >
          <span className="flex w-6 shrink-0 items-center justify-center font-mono text-muted-foreground">
            {i === 0 ? (
              <Crown className="h-4 w-4 text-chart-3" />
            ) : i === 1 || i === 2 ? (
              <Medal
                className={cn(
                  'h-4 w-4',
                  i === 1 ? 'text-muted-foreground' : 'text-chart-5',
                )}
              />
            ) : (
              i + 1
            )}
          </span>
          <span className="flex-1 truncate font-medium text-foreground">
            {row.playerName}
            {row.isMe && (
              <span className="ml-2 text-xs font-normal text-primary">
                (you)
              </span>
            )}
          </span>
          <span className="font-mono font-semibold text-foreground">
            {row.score.toLocaleString()}
          </span>
          <span className="w-14 shrink-0 text-right text-xs text-muted-foreground">
            {scoreLabel}
          </span>
        </li>
      ))}
    </ol>
  )
}
