import { Hash, Grid3x3, Worm, Layers, Hammer, LayoutGrid } from 'lucide-react'

const GLYPHS: Record<string, typeof Hash> = {
  'tic-tac-toe': Hash,
  '2048': LayoutGrid,
  snake: Worm,
  'memory-match': Layers,
  'whack-a-mole': Hammer,
  sudoku: Grid3x3,
}

export function GameGlyph({
  slug,
  className,
}: {
  slug: string
  className?: string
}) {
  const Icon = GLYPHS[slug] ?? Hash
  return <Icon className={className} aria-hidden="true" />
}
