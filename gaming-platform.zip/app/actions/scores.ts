'use server'

import { auth } from '@/lib/auth'
import { db } from '@/lib/db'
import { gameScores } from '@/lib/db/schema'
import { and, asc, desc, eq } from 'drizzle-orm'
import { headers } from 'next/headers'
import { revalidatePath } from 'next/cache'
import { getGame } from '@/lib/games'

async function getSessionUser() {
  const session = await auth.api.getSession({ headers: await headers() })
  return session?.user ?? null
}

export type ScoreRow = {
  id: number
  playerName: string
  score: number
  createdAt: Date
  isMe: boolean
}

/**
 * Submit a score for the signed-in user. Silently no-ops when signed out so
 * guests can still play; the UI prompts them to sign in to save.
 */
export async function submitScore(game: string, score: number) {
  const meta = getGame(game)
  if (!meta || !meta.hasLeaderboard) return { saved: false as const }
  if (!Number.isFinite(score)) return { saved: false as const }

  const user = await getSessionUser()
  if (!user) return { saved: false as const }

  await db.insert(gameScores).values({
    userId: user.id,
    playerName: user.name,
    game,
    score: Math.round(score),
  })

  revalidatePath(`/games/${game}`)
  revalidatePath('/leaderboards')
  return { saved: true as const }
}

/**
 * Top scores for a game. Returns each player's best result, ordered by the
 * game's ranking direction (higher-is-better vs. lower-is-better).
 */
export async function getTopScores(game: string, limit = 10): Promise<ScoreRow[]> {
  const meta = getGame(game)
  if (!meta || !meta.hasLeaderboard) return []

  const user = await getSessionUser()

  const rows = await db
    .select()
    .from(gameScores)
    .where(eq(gameScores.game, game))
    .orderBy(
      meta.higherIsBetter ? desc(gameScores.score) : asc(gameScores.score),
    )
    .limit(200)

  // Reduce to each player's best score.
  const best = new Map<string, (typeof rows)[number]>()
  for (const row of rows) {
    const current = best.get(row.userId)
    if (!current) {
      best.set(row.userId, row)
      continue
    }
    const better = meta.higherIsBetter
      ? row.score > current.score
      : row.score < current.score
    if (better) best.set(row.userId, row)
  }

  return Array.from(best.values())
    .sort((a, b) =>
      meta.higherIsBetter ? b.score - a.score : a.score - b.score,
    )
    .slice(0, limit)
    .map((row) => ({
      id: row.id,
      playerName: row.playerName,
      score: row.score,
      createdAt: row.createdAt,
      isMe: user?.id === row.userId,
    }))
}

/** The signed-in user's personal best for a game, or null. */
export async function getMyBest(game: string): Promise<number | null> {
  const meta = getGame(game)
  if (!meta || !meta.hasLeaderboard) return null
  const user = await getSessionUser()
  if (!user) return null

  const rows = await db
    .select()
    .from(gameScores)
    .where(and(eq(gameScores.game, game), eq(gameScores.userId, user.id)))
    .orderBy(
      meta.higherIsBetter ? desc(gameScores.score) : asc(gameScores.score),
    )
    .limit(1)

  return rows[0]?.score ?? null
}
