import type { Metadata } from 'next'
import { GAMES } from '@/lib/games'
import { GameCard } from '@/components/game-card'
import { AdSlot } from '@/components/ad-slot'

export const metadata: Metadata = {
  title: 'All Games — Arcadia',
  description:
    'Browse every free casual game on Arcadia: Tic-Tac-Toe, 2048, Snake, Memory Match, Whack-a-Mole, and Sudoku.',
}

export default function GamesPage() {
  return (
    <main className="mx-auto max-w-7xl px-4 py-12">
      <header className="max-w-2xl">
        <h1 className="text-4xl font-bold tracking-tight text-foreground">
          All games
        </h1>
        <p className="mt-3 text-pretty leading-relaxed text-muted-foreground">
          {GAMES.length} free games to play instantly. Pick one and start
          playing — no download required.
        </p>
      </header>

      <div className="mt-8">
        <AdSlot format="horizontal" slot="4444444444" className="h-24 md:h-28" />
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_300px]">
        <div className="grid gap-5 sm:grid-cols-2">
          {GAMES.map((game) => (
            <GameCard key={game.slug} game={game} />
          ))}
        </div>

        <aside className="hidden lg:block">
          <div className="sticky top-24">
            <AdSlot format="vertical" slot="5555555555" className="h-[600px]" />
          </div>
        </aside>
      </div>
    </main>
  )
}
