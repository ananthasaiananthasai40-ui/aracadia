import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { ChevronLeft, Trophy, Users } from 'lucide-react'
import { GAMES, getGame } from '@/lib/games'
import { getMyBest, getTopScores } from '@/app/actions/scores'
import { GameRunner } from '@/components/game-runner'
import { Leaderboard } from '@/components/leaderboard'
import { AdSlot } from '@/components/ad-slot'
import { GameGlyph } from '@/components/game-glyph'
import { Badge } from '@/components/ui/badge'

export function generateStaticParams() {
  return GAMES.map((g) => ({ slug: g.slug }))
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>
}): Promise<Metadata> {
  const { slug } = await params
  const game = getGame(slug)
  if (!game) return { title: 'Game not found — Arcadia' }
  return {
    title: `${game.name} — Play free on Arcadia`,
    description: game.description,
  }
}

export default async function GamePage({
  params,
}: {
  params: Promise<{ slug: string }>
}) {
  const { slug } = await params
  const game = getGame(slug)
  if (!game) notFound()

  const [topScores, myBest] = await Promise.all([
    game.hasLeaderboard ? getTopScores(game.slug, 10) : Promise.resolve([]),
    game.hasLeaderboard ? getMyBest(game.slug) : Promise.resolve(null),
  ])

  return (
    <main className="mx-auto max-w-7xl px-4 py-8">
      <Link
        href="/games"
        className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
      >
        <ChevronLeft className="h-4 w-4" />
        All games
      </Link>

      <div className="mt-4 flex items-start gap-4">
        <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-secondary text-primary">
          <GameGlyph slug={game.slug} className="h-7 w-7" />
        </span>
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">
            {game.name}
          </h1>
          <p className="mt-1 max-w-2xl text-pretty leading-relaxed text-muted-foreground">
            {game.description}
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Badge variant="secondary">{game.category}</Badge>
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <Users className="h-3.5 w-3.5" />
              {game.players}
            </span>
          </div>
        </div>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_320px]">
        <div className="flex flex-col gap-6">
          <GameRunner game={game} />
          {/* In-content ad below the game */}
          <AdSlot format="horizontal" slot="7777777777" className="h-24 md:h-28" />
        </div>

        <aside className="flex flex-col gap-6">
          {game.hasLeaderboard ? (
            <section className="rounded-2xl border border-border bg-card/50 p-5">
              <div className="mb-4 flex items-center gap-2">
                <Trophy className="h-4 w-4 text-primary" />
                <h2 className="font-bold text-foreground">Leaderboard</h2>
              </div>
              {myBest !== null && (
                <p className="mb-3 rounded-lg bg-secondary px-3 py-2 text-sm text-foreground">
                  Your best {game.scoreLabel.toLowerCase()}:{' '}
                  <span className="font-mono font-semibold">{myBest}</span>
                </p>
              )}
              <Leaderboard rows={topScores} scoreLabel={game.scoreLabel} />
            </section>
          ) : (
            <section className="rounded-2xl border border-border bg-card/50 p-5">
              <h2 className="font-bold text-foreground">How to play</h2>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {game.tagline}. This game is just for fun — no score is recorded.
                Jump in and enjoy!
              </p>
            </section>
          )}

          {/* Sidebar ad */}
          <div className="hidden lg:block">
            <AdSlot format="rectangle" slot="8888888888" className="h-64" />
          </div>
        </aside>
      </div>
    </main>
  )
}
