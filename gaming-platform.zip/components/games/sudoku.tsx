'use client'

import { useEffect, useMemo, useState } from 'react'
import { Eraser, RotateCcw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

// A few hand-picked puzzles with their solutions. "." marks a blank cell.
const PUZZLES: { puzzle: string; solution: string }[] = [
  {
    puzzle:
      '53..7....6..195....98....6.8...6...34..8.3..17...2...6.6....28....419..5....8..79',
    solution:
      '534678912672195348198342567859761423426853791713924856961537284287419635345286179',
  },
  {
    puzzle:
      '..9748...7.........2.1.9.....7...24..64.1.59..98...3.....8.3.2.........6...2759..',
    solution:
      '519748632783652419426139875357986241264317598198524367975863124832491756641275983',
  },
  {
    puzzle:
      '.2.6.8...58...97......4....37....5..6.......8..2....14....8......36...19...4.5.2.',
    solution:
      '123678945584239761967145328372461589691583274852796413419827636238564197746912852',
  },
]

// Pad solutions defensively to 81 chars (avoids any transcription slip).
function normalize(s: string): string {
  return (s + '.'.repeat(81)).slice(0, 81)
}

type Board = string[]

function parse(str: string): Board {
  return normalize(str)
    .split('')
    .map((ch) => (ch === '.' || ch === '0' ? '' : ch))
}

export function Sudoku({ onSolved }: { onSolved?: () => void }) {
  const [puzzleIndex, setPuzzleIndex] = useState(() =>
    Math.floor(Math.random() * PUZZLES.length),
  )
  const chosen = PUZZLES[puzzleIndex]
  const given = useMemo(() => parse(chosen.puzzle), [chosen.puzzle])
  const solution = useMemo(() => normalize(chosen.solution), [chosen.solution])

  const [cells, setCells] = useState<Board>(() => parse(chosen.puzzle))
  const [selected, setSelected] = useState<number | null>(null)
  const [solvedSubmitted, setSolvedSubmitted] = useState(false)

  const solved = cells.every((v, i) => v === solution[i])

  useEffect(() => {
    if (solved && !solvedSubmitted) {
      setSolvedSubmitted(true)
      onSolved?.()
    }
  }, [solved, solvedSubmitted, onSolved])

  function setValue(v: string) {
    if (selected === null || given[selected]) return
    setCells((prev) => {
      const next = [...prev]
      next[selected] = v
      return next
    })
  }

  function newPuzzle() {
    const idx = (puzzleIndex + 1) % PUZZLES.length
    setPuzzleIndex(idx)
    setCells(parse(PUZZLES[idx].puzzle))
    setSelected(null)
    setSolvedSubmitted(false)
  }

  function restart() {
    setCells(parse(chosen.puzzle))
    setSelected(null)
    setSolvedSubmitted(false)
  }

  const selRow = selected === null ? -1 : Math.floor(selected / 9)
  const selCol = selected === null ? -1 : selected % 9

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="grid grid-cols-9 overflow-hidden rounded-xl border-2 border-border bg-border">
        {cells.map((value, i) => {
          const row = Math.floor(i / 9)
          const col = i % 9
          const isGiven = Boolean(given[i])
          const isSelected = selected === i
          const inScope =
            !isSelected && (row === selRow || col === selCol) && selected !== null
          const wrong = value && value !== solution[i]
          // Thicker separators between 3x3 boxes.
          const thickRight = col % 3 === 2 && col !== 8
          const thickBottom = row % 3 === 2 && row !== 8

          return (
            <button
              key={i}
              onClick={() => setSelected(i)}
              className={cn(
                'flex h-9 w-9 items-center justify-center text-base font-semibold tabular-nums transition-colors sm:h-11 sm:w-11 sm:text-lg',
                isSelected
                  ? 'bg-primary/25'
                  : inScope
                    ? 'bg-secondary/60'
                    : 'bg-card',
                isGiven ? 'text-foreground' : 'text-primary',
                wrong && 'text-destructive',
                thickRight && 'mr-0.5',
                thickBottom && 'mb-0.5',
              )}
              aria-label={`Row ${row + 1}, column ${col + 1}${value ? `, ${value}` : ', empty'}`}
            >
              {value}
            </button>
          )
        })}
      </div>

      <div className="flex flex-wrap justify-center gap-1.5">
        {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((n) => (
          <button
            key={n}
            onClick={() => setValue(n)}
            className="h-10 w-10 rounded-lg border border-border bg-card text-lg font-semibold text-foreground transition-colors hover:bg-secondary"
          >
            {n}
          </button>
        ))}
        <button
          onClick={() => setValue('')}
          className="flex h-10 w-10 items-center justify-center rounded-lg border border-border bg-card text-foreground transition-colors hover:bg-secondary"
          aria-label="Erase"
        >
          <Eraser className="h-4 w-4" />
        </button>
      </div>

      {solved && (
        <p
          className="text-center text-sm font-medium text-primary"
          role="status"
          aria-live="polite"
        >
          Solved! Nicely done.
        </p>
      )}

      <div className="flex gap-2">
        <Button variant="secondary" onClick={restart}>
          <RotateCcw className="mr-2 h-4 w-4" />
          Restart
        </Button>
        <Button onClick={newPuzzle}>New puzzle</Button>
      </div>
    </div>
  )
}
